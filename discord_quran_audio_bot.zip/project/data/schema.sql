CREATE TABLE IF NOT EXISTS guild_settings (
  guild_id INTEGER PRIMARY KEY,
  enable_query_search INTEGER DEFAULT 1,
  max_search_results INTEGER DEFAULT 5,
  use_cookies INTEGER DEFAULT 1,
  idle_minutes INTEGER DEFAULT 10,
  max_queue_size INTEGER DEFAULT 300,
  volume INTEGER DEFAULT 70,
  dj_role_id INTEGER
);

CREATE TABLE IF NOT EXISTS guild_cookies (
  guild_id INTEGER NOT NULL,
  provider TEXT NOT NULL,
  blob_encrypted BLOB NOT NULL,
  last_validated_at TEXT,
  is_valid INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, provider)
);
