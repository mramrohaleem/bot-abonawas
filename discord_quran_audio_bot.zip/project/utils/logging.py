from __future__ import annotations

import contextvars
import logging
import os
import re
import sys
from datetime import datetime
from logging.handlers import RotatingFileHandler
from typing import Any, Dict

from pythonjsonlogger import jsonlogger

trace_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("trace_id", default="-")


class RedactFilter(logging.Filter):
    SENSITIVE_KEYS = re.compile(r"(token|authorization|cookie)", re.I)

    def filter(self, record: logging.LogRecord) -> bool:  # type: ignore[override]
        # Redact in message
        record.msg = self._redact_text(str(record.msg))
        # Redact in extra dict if exists
        if hasattr(record, "__dict__"):
            for k, v in list(record.__dict__.items()):
                if isinstance(v, str) and self.SENSITIVE_KEYS.search(k):
                    record.__dict__[k] = "[REDACTED]"
        return True

    def _redact_text(self, s: str) -> str:
        # naive redaction of tokens-like strings
        s = re.sub(r"(?i)(token|authorization|cookie)[=:]\s*[^\s]+", r"\1=[REDACTED]", s)
        return s


class JsonFormatter(jsonlogger.JsonFormatter):
    def add_fields(self, log_record: Dict[str, Any], record: logging.LogRecord, message_dict: Dict[str, Any]) -> None:  # noqa: D401
        super().add_fields(log_record, record, message_dict)
        log_record.setdefault("ts", datetime.utcnow().isoformat() + "Z")
        log_record.setdefault("level", record.levelname)
        log_record.setdefault("trace_id", trace_id_var.get())
        log_record.setdefault("component", getattr(record, "component", "app"))


def init_logger() -> logging.Logger:
    level = os.getenv("LOG_LEVEL", "INFO").upper()
    fmt = os.getenv("LOG_FORMAT", "json")
    log_file = os.getenv("LOG_FILE", "logs/bot.jsonl")
    os.makedirs(os.path.dirname(log_file), exist_ok=True)

    root = logging.getLogger()
    root.setLevel(getattr(logging, level, logging.INFO))

    # Console handler
    ch = logging.StreamHandler(sys.stdout)
    if fmt == "json":
        ch.setFormatter(JsonFormatter())
    else:
        ch.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s %(name)s: %(message)s"))
    ch.addFilter(RedactFilter())
    root.addHandler(ch)

    # Rotating file handler
    max_bytes = int(os.getenv("LOG_MAX_BYTES", "10485760"))
    backups = int(os.getenv("LOG_BACKUPS", "5"))
    fh = RotatingFileHandler(log_file, maxBytes=max_bytes, backupCount=backups, encoding="utf-8")
    fh.setFormatter(JsonFormatter())
    fh.addFilter(RedactFilter())
    root.addHandler(fh)

    return root


def with_trace(func):  # type: ignore[no-redef]
    async def wrapper(*args, **kwargs):
        import uuid

        token = trace_id_var.set(uuid.uuid4().hex[:12])
        try:
            return await func(*args, **kwargs)
        finally:
            trace_id_var.reset(token)

    return wrapper


def log_event(level: int, event: str, component: str, **fields: Any) -> None:
    logger = logging.getLogger(component)
    extra = {"component": component, **fields}
    logger.log(level, event, extra=extra)


# Classifiers — simplified heuristics
def classify_yt_dlp_error(e: Exception) -> str:
    s = str(e).lower()
    if "age" in s and "verify" in s:
        return "age_gate"
    if "geo" in s or "region" in s:
        return "geo_block"
    if "signatur" in s:
        return "signature_failed"
    if "http error" in s:
        return "http_error"
    return "extractor_error"


def classify_ffmpeg_exit(code: int, stderr: str) -> str:
    s = stderr.lower()
    if "403" in s:
        return "http_forbidden_403"
    if "reset" in s:
        return "connection_reset"
    if "invalid data" in s:
        return "invalid_data"
    if "timeout" in s:
        return "timeout"
    return f"exit_{code}"
