from __future__ import annotations

import base64
import os
import tempfile
from typing import Optional, Tuple

from cryptography.fernet import Fernet

from .db import Database
from .logging import log_event
from . import ytdlp_helper


class CookiesStore:
    def __init__(self, db: Database) -> None:
        self.db = db
        key_b64 = os.getenv("COOKIES_ENCRYPTION_KEY")
        if not key_b64:
            # For safety, generate ephemeral key if not provided (not persistent). Recommend setting via .env
            key_b64 = base64.urlsafe_b64encode(Fernet.generate_key()).decode()
        self.fernet = Fernet(key_b64)

    async def save_cookies(self, guild_id: int, provider: str, data: bytes) -> None:
        token = self.fernet.encrypt(data)
        await self.db.upsert_cookies(guild_id, provider, token)
        log_event(20, "cookies_saved", "cookies", guild_id=guild_id, provider=provider, has_cookies=True)

    async def info(self, guild_id: int):
        out = []
        for provider in ("youtube", "facebook"):
            row = await self.db.get_cookies(guild_id, provider)
            if row:
                out.append(row)
        return out

    async def delete(self, guild_id: int, provider: str) -> None:
        await self.db.delete_cookies(guild_id, provider)
        log_event(20, "cookies_deleted", "cookies", guild_id=guild_id, provider=provider)

    async def get_temp_path(self, guild_id: int, provider: str) -> Optional[str]:
        row = await self.db.get_cookies(guild_id, provider)
        if not row:
            return None
        data = self.fernet.decrypt(row["blob_encrypted"])  # type: ignore[index]
        fd, path = tempfile.mkstemp(prefix=f"{provider}_", suffix="_cookies.txt")
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        return path

    async def validate(self, guild_id: int, provider: str) -> Tuple[bool, str]:
        temp = await self.get_temp_path(guild_id, provider)
        if not temp:
            return (False, "no_cookies")
        try:
            url = "https://www.youtube.com/watch?v=BaW_jenozKc" if provider == "youtube" else "https://www.facebook.com/watch/"
            await ytdlp_helper.extract_single(url, guild_id=guild_id, cookies_path=temp)
            await self.db.update_cookie_validation(guild_id, provider, True)
            return (True, "ok")
        except Exception as e:  # noqa: BLE001
            await self.db.update_cookie_validation(guild_id, provider, False)
            return (False, str(e)[:200])
        finally:
            try:
                os.remove(temp)
            except Exception:
                pass
