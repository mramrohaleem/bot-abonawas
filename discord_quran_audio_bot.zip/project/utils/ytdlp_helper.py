from __future__ import annotations

import asyncio
import logging
import os
from functools import partial
from typing import Any, Dict, List, Optional

import yt_dlp as ytdlp  # type: ignore

from .logging import log_event, classify_yt_dlp_error

LOG = logging.getLogger(__name__)


def _base_opts(cookies_path: Optional[str] = None, flat: bool = False) -> Dict[str, Any]:
    ydl_opts: Dict[str, Any] = {
        "format": "bestaudio/best",
        "quiet": True,
        "nocheckcertificate": True,
        "noplaylist": False,
        "extract_flat": flat,
        "skip_download": True,
        "cachedir": False,
        "postprocessors": [],
        "http_headers": {
            "User-Agent": "Mozilla/5.0",
        },
    }
    if cookies_path:
        ydl_opts["cookiefile"] = cookies_path
    return ydl_opts


async def run_ydl(func, *args, **kwargs):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, partial(func, *args, **kwargs))


async def search_yt(query: str, limit: int = 5, guild_id: Optional[int] = None) -> List[Dict[str, Any]]:
    # flat search for speed
    ydl_opts = _base_opts(flat=True)
    search_query = f"ytsearch{limit}:{query}"
    try:
        with ytdlp.YoutubeDL(ydl_opts) as ydl:
            info = await run_ydl(ydl.extract_info, search_query, False)
    except Exception as e:  # noqa: BLE001
        log_event(logging.ERROR, "search_error", "search", guild_id=guild_id, query=query, message=str(e))
        raise
    entries = info.get("entries", []) if isinstance(info, dict) else []
    log_event(logging.INFO, "search_ok", "search", guild_id=guild_id, query=query, results_count=len(entries))
    return entries


async def extract_single(url: str, guild_id: Optional[int] = None, cookies_path: Optional[str] = None) -> Dict[str, Any]:
    attempts = 0
    allow_auto = os.getenv("ALLOW_YTDLP_AUTOUPDATE", "true").lower() == "true"
    use_cookies = True if cookies_path else False

    while attempts < 3:
        attempts += 1
        try:
            ydl_opts = _base_opts(cookies_path=cookies_path)
            with ytdlp.YoutubeDL(ydl_opts) as ydl:
                info = await run_ydl(ydl.extract_info, url, False)
                if "entries" in info:
                    # playlist — take first entry
                    info = info["entries"][0]
                log_event(logging.INFO, "extract_ok", "extractor", guild_id=guild_id, url=url, elapsed_ms=0)
                return info
        except Exception as e:  # noqa: BLE001
            kind = classify_yt_dlp_error(e)
            log_event(logging.WARNING, "extract_fail", "extractor", guild_id=guild_id, url=url, error_kind=kind, attempt=attempts)
            # retry logic: if first attempt and no cookies and error indicates gate → try cookies (env/global path)
            if attempts == 1 and not use_cookies and os.getenv("YTDLP_COOKIES_PATH"):
                cookies_path = os.getenv("YTDLP_COOKIES_PATH")
                use_cookies = True
                continue
            if attempts == 2 and allow_auto:
                # try update
                ok, _ = await autoupdate()
                if ok:
                    continue
            if attempts >= 3:
                raise


async def autoupdate() -> (bool, str):
    try:
        proc = await asyncio.create_subprocess_exec(
            "yt-dlp", "-U",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        out, _ = await proc.communicate()
        text = out.decode(errors="ignore")
        ok = proc.returncode == 0
        log_event(logging.INFO if ok else logging.ERROR, "ytdlp_update", "admin", message=text)
        return ok, text
    except FileNotFoundError:
        return False, "yt-dlp command not found"


async def versions() -> Dict[str, str]:
    # yt-dlp version
    try:
        yv = ytdlp.version.__version__  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001
        yv = "unknown"
    # ffmpeg
    try:
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-version",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        out, _ = await proc.communicate()
        ffv = out.decode(errors="ignore").split("\n", 1)[0]
    except Exception:  # noqa: BLE001
        ffv = "ffmpeg not found"
    return {"yt_dlp": yv, "ffmpeg": ffv}
