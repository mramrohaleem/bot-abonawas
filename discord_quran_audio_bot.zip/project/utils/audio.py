from __future__ import annotations

import asyncio
import logging
from typing import Optional

import discord

from .logging import log_event, classify_ffmpeg_exit

LOG = logging.getLogger(__name__)

FFMPEG_BEFORE_BASE = "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5 -nostdin"
FFMPEG_OPTIONS = "-vn -ac 2 -f s16le -ar 48000 -filter:a loudnorm=i=-16:tp=-1.5"


class DiscordPCMVolumeTransformer(discord.PCMVolumeTransformer):
    def __init__(self, original: discord.AudioSource, volume: float) -> None:
        super().__init__(original, volume=volume)


async def create_ffmpeg_source_with_retries(input_url: str, volume: int = 70, guild_id: Optional[int] = None, seek_seconds: Optional[int] = None) -> discord.AudioSource:
    attempts = 0
    last_err: Optional[str] = None
    before_opts = FFMPEG_BEFORE_BASE
    if seek_seconds is not None and seek_seconds > 0:
        before_opts = f"-ss {int(seek_seconds)} " + before_opts
    while attempts < 3:
        attempts += 1
        try:
            src = discord.FFmpegPCMAudio(
                source=input_url,
                before_options=before_opts,
                options=FFMPEG_OPTIONS,
            )
            vol = max(0.0, min(1.0, volume / 100.0))
            wrapped = DiscordPCMVolumeTransformer(src, volume=vol)
            return wrapped
        except Exception as e:  # noqa: BLE001
            last_err = str(e)
            await asyncio.sleep(1.0 * attempts)
    err_kind = classify_ffmpeg_exit(-1, last_err or "")
    log_event(logging.ERROR, "ffmpeg_fail", "ffmpeg", guild_id=guild_id, stderr_snippet=(last_err or "")[:200])
    raise RuntimeError(f"تعذّر فتح المصدر الصوتي: {err_kind}")
