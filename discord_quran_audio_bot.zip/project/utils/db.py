from __future__ import annotations

import aiosqlite
from typing import Any, Dict, Optional
import os

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS guild_settings (
  guild_id INTEGER PRIMARY KEY,
  enable_query_search INTEGER DEFAULT 1,
  max_search_results INTEGER DEFAULT 5,
  use_cookies INTEGER DEFAULT 1,
  idle_minutes INTEGER DEFAULT 10,
  max_queue_size INTEGER DEFAULT 300,
  volume INTEGER DEFAULT 70,
  dj_role_id INTEGER
);

CREATE TABLE IF NOT EXISTS guild_cookies (
  guild_id INTEGER NOT NULL,
  provider TEXT NOT NULL,
  blob_encrypted BLOB NOT NULL,
  last_validated_at TEXT,
  is_valid INTEGER DEFAULT 0,
  PRIMARY KEY (guild_id, provider)
);
"""


class Database:
    def __init__(self, path: str) -> None:
        self.path = path
        os.makedirs(os.path.dirname(path), exist_ok=True)

    async def initialize(self) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.executescript(SCHEMA_SQL)
            await db.commit()

    async def get_settings(self, guild_id: int) -> Dict[str, Any]:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM guild_settings WHERE guild_id=?", (guild_id,)) as cur:
                row = await cur.fetchone()
                if row:
                    return dict(row)
            # Insert defaults
            await db.execute("INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)", (guild_id,))
            await db.commit()
            return {
                "guild_id": guild_id,
                "enable_query_search": 1,
                "max_search_results": 5,
                "use_cookies": 1,
                "idle_minutes": 10,
                "max_queue_size": 300,
                "volume": 70,
                "dj_role_id": None,
            }

    async def set_setting(self, guild_id: int, key: str, value: Any) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                f"UPDATE guild_settings SET {key}=? WHERE guild_id=?",
                (value, guild_id),
            )
            await db.commit()

    # Cookies
    async def upsert_cookies(self, guild_id: int, provider: str, blob_encrypted: bytes) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "INSERT INTO guild_cookies (guild_id, provider, blob_encrypted) VALUES (?,?,?)\n"
                "ON CONFLICT(guild_id, provider) DO UPDATE SET blob_encrypted=excluded.blob_encrypted",
                (guild_id, provider, blob_encrypted),
            )
            await db.commit()

    async def get_cookies(self, guild_id: int, provider: str) -> Optional[Dict[str, Any]]:
        async with aiosqlite.connect(self.path) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute(
                "SELECT * FROM guild_cookies WHERE guild_id=? AND provider=?",
                (guild_id, provider),
            ) as cur:
                row = await cur.fetchone()
                return dict(row) if row else None

    async def delete_cookies(self, guild_id: int, provider: str) -> None:
        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "DELETE FROM guild_cookies WHERE guild_id=? AND provider=?",
                (guild_id, provider),
            )
            await db.commit()

    async def update_cookie_validation(self, guild_id: int, provider: str, ok: bool) -> None:
        import datetime as dt

        async with aiosqlite.connect(self.path) as db:
            await db.execute(
                "UPDATE guild_cookies SET is_valid=?, last_validated_at=? WHERE guild_id=? AND provider=?",
                (1 if ok else 0, dt.datetime.utcnow().isoformat()+"Z", guild_id, provider),
            )
            await db.commit()
