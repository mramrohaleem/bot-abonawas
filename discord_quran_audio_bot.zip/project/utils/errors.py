class QueueEmptyError(Exception):
    pass


class PermissionDeniedError(Exception):
    pass


class VoiceNotConnectedError(Exception):
    pass
